

import java.util.Scanner;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Scanner LineReader = new Scanner(System.in);
        calculator C1 = new calculator();

        C1.info();
        C1.get_start_time();


        //
        System.out.println("podaj liczbie 1: ");
        Double liczba1 = LineReader.nextDouble();
        //
        System.out.println("podaj liczbie 2: ");
        Double liczba2 = LineReader.nextDouble();

        C1.all(liczba1, liczba2);
        /*C1.add(liczba1, liczba2);
        C1.sub(liczba1, liczba2);
        C1.mul(liczba1, liczba2);
        C1.div(liczba1, liczba2);
        */
        

        /*char liczba1 = LineReader.nextByte();
        try {
            Double.parseDouble(liczba1);
        }
        catch (NumberFormatException  e) {
            System.out.println(" NOT loaded correctly!!\n\n");
            e.printStackTrace();
        }
        */

    }
}
